


employeeCategory = int(input("Enter employee's Category"))
State = input("Enter the state:");
 

if employeeCategory == 1 and State in ["NY","NJ","PA"]: 

     print("Employee Jacket Color is: Blue")

elif employeeCategory == 1 and State in ["TX","LA","FL"]:
       
    print("Employee Jacket Color is: White")
 


 
if employeeCategory == 2 and State in ["NY","NJ","PA"]: 

     print("Employee Jacket Color is: Purple")

elif employeeCategory == 2 and State in ["TX","LA","FL"]:
       print("Employee Jacket Color is: Green")
 


 
if employeeCategory == 3 and State in ["NY","NJ","PA"]: 

     print("Employee Jacket Color is: Red")

elif employeeCategory == 3 and State in ["TX","LA","FL"]:
       print("Employee Jacket Color is: Maroon")
 


 
if employeeCategory == 4 and State in ["NY","NJ","PA"]: 

     print("Employee Jacket Color is: Black")

elif employeeCategory == 4 and State in ["TX","LA","FL"]:
       print("Employee Jacket Color is: Gray")
 
